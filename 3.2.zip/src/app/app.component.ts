import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Hello, PrimeNg';
  data: any;

  ngOnInit(): void {
    this.data = {
      labels: ['Casa', 'Lavoro', 'Viaggi'],
      datasets: [
        {
          backgroundColor: [
            '#FF6384',
            '#36A2EB',
            '#FFCE56'
          ],
          hoverBackgroundColor: [
            '#FF6384',
            '#36A2EB',
            '#FFCE56'
          ],
          data: [350, 70, 220]
        },
      ]
    };
  }
}
