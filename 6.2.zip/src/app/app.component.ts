import {Component, OnInit} from '@angular/core';
import {Invoice} from './model/Invoice';
import {SelectItem} from 'primeng';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  TAX = 27;
  title = 'Create Invoice';
  invoiceForm: FormGroup;
  types: SelectItem[];
  states: SelectItem[];
  it: any;
  minDate: Date;
  maxDate: Date;
  customers: string[];
  filteredCustomers: string[];

  constructor(private formBuilder: FormBuilder) {
    const num = this.generateInvoiceNumber(new Date());
    this.invoiceForm = this.formBuilder.group({
      number: [num],
      customerFrom: ['', Validators.compose([Validators.minLength(4), Validators.required])],
      customerTo: [''],
      dateFrom: [new Date()],
      dateTo: [new Date()],
      amount: [100],
      tax: new FormControl({ value: 27, disabled: true }),
      total: new FormControl({ value: 127, disabled: true }),
      type: ['luce'],
      description: [''],
      state: ['emessa']
    });

    const total = this.invoiceForm.get('total');
    const tax = this.invoiceForm.get('tax');
    const invoiceNumber = this.invoiceForm.get('number');
    this.invoiceForm.valueChanges.subscribe(val => {
      const taxValue = (val.amount / 100) * this.TAX;
      tax.patchValue(taxValue, { emitEvent: false });
      total.patchValue(val.amount + taxValue, { emitEvent: false });
      invoiceNumber.patchValue(this.generateInvoiceNumber(new Date(val.dateFrom), val.type), { emitEvent: false });
    });
  }

  ngOnInit(): void {
    this.customers = [
      'Apple Inc',
      'Google',
      'Fiat',
      'Netflix',
      'Amazon',
      'Tesla'
    ];
    this.minDate = new Date();
    this.maxDate = new Date();
    this.maxDate.setMonth((this.minDate.getMonth() + 3) % 11);
    this.it = {
      firstDayOfWeek: 1,
      dayNames: ['Domenica', 'Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato'],
      dayNamesShort: ['DOM', 'LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB'],
      dayNamesMin: ['D', 'L', 'M', 'M', 'G', 'V', 'S'],
      monthNames: ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'],
      monthNamesShort: ['GEN', 'FEB', 'MAR', 'APR', 'MAG', 'GIU', 'LUG', 'AGO', 'SET', 'OTT', 'NOV', 'DIC'],
      today: 'Oggi',
      clear: 'Cancella',
    };
    this.types = [
      { label: 'Luce', value: 'luce' },
      { label: 'Gas', value: 'gas' },
      { label: 'Luce/Gas', value: 'luce/gas' },
    ];
    this.states = [
      { label: 'Non emessa', value: 'non_emessa' },
      { label: 'Emessa', value: 'emessa' },
      { label: 'Pagata', value: 'pagata' },
      { label: 'Nota di credito', value: 'ncr' }
    ];
  }

  filterCustomer(event: any) {
    this.filteredCustomers = [];
    const search = event.query;
    for (const customer of this.customers) {
      if (customer.includes(search)) {
        this.filteredCustomers.push(customer);
      }
    }
  }

  generateInvoiceNumber(date: Date, type: string = 'luce'): string {
    const dateStr = this.getFormattedDate(date);
    const t = this.getType(type);
    return `FAT${t}${dateStr}000000`;
  }

  getType(type: string): string {
    let toRet = 'A';
    if (type === 'luce') {
      toRet = 'L';
    } else if (type === 'gas') {
      toRet = 'G';
    }
    return toRet;
  }

  getFormattedDate(date: Date): string {
    let toRet = '';
    const day = date.getDate();
    if (day < 10) {
      toRet += '0' + day;
    } else {
      toRet += day;
    }
    const month = date.getMonth() + 1;
    if (month < 10) {
      toRet += '0' + month;
    } else {
      toRet += month;
    }
    toRet += date.getFullYear();
    return toRet;
  }

  get customerFrom() {
    return this.invoiceForm.get('customerFrom');
  }
}
