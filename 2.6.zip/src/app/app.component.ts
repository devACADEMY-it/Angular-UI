import {Component, OnInit} from '@angular/core';
import {Contract} from './model/Contract';
// @ts-ignore
import { contracts } from '../assets/contracts.json';
import {FilterUtils} from 'primeng/utils';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Hello, PrimeNg';
  contracts: Contract[];
  columns: any[];
  states: any[];

  ngOnInit(): void {
    this.contracts = contracts;
    this.columns = [
      { field: 'customer', label: 'Cliente' },
      { field: 'city', label: 'Città' },
      { field: 'registrationDate', label: 'Data inizio' },
      { field: 'endDate', label: 'Data fine' },
      { field: 'status', label: 'Stato' },
      { field: 'power', label: 'Potenza' }
    ];
    this.states = [
      { label: 'TUTTI', value: null },
      { label: 'ACTIVE', value: 'active' },
      { label: 'INACTIVE', value: 'inactive' },
      { label: 'WORKING', value: 'working' }
    ];
    FilterUtils['custom'] = (value, filter) => {
      if (filter === undefined || filter === null || filter.trim() === '') {
        return true;
      }

      if (value === undefined || value === null) {
        return false;
      }

      return parseInt(filter, 10) > value;
    };
  }

  formatDate(timestamp: number) {
    return new Date(timestamp).toLocaleDateString();
  }
}
