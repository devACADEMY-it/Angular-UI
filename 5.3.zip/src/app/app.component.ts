import {Component, OnInit} from '@angular/core';
import {Invoice} from './model/Invoice';
import {SelectItem} from 'primeng';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Create Invoice';
  invoiceForm: FormGroup;
  types: SelectItem[];
  states: SelectItem[];
  it: any;

  constructor(private formBuilder: FormBuilder) {
    const num = this.generateInvoiceNumber(new Date());
    this.invoiceForm = this.formBuilder.group({
      number: [num],
      customerFrom: [''],
      customerTo: [''],
      dateFrom: [new Date()],
      dateTo: [new Date()],
      amount: [1],
      tax: [27],
      total: new FormControl({ value: 28, disabled: true }),
      type: ['luce'],
      description: [''],
      state: ['emessa']
    });

    const total = this.invoiceForm.get('total');
    const invoiceNumber = this.invoiceForm.get('number');
    this.invoiceForm.valueChanges.subscribe(val => {
      total.patchValue(val.amount + val.tax, { emitEvent: false });
      invoiceNumber.patchValue(this.generateInvoiceNumber(new Date(val.dateFrom), val.type), { emitEvent: false });
    });
  }

  ngOnInit(): void {
    this.it = {
      firstDayOfWeek: 1,
      dayNames: ['Domenica', 'Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato'],
      dayNamesShort: ['DOM', 'LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB'],
      dayNamesMin: ['D', 'L', 'M', 'M', 'G', 'V', 'S'],
      monthNames: ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'],
      monthNamesShort: ['GEN', 'FEB', 'MAR', 'APR', 'MAG', 'GIU', 'LUG', 'AGO', 'SET', 'OTT', 'NOV', 'DIC'],
      today: 'Oggi',
      clear: 'Cancella',
    };
    this.types = [
      { label: 'Luce', value: 'luce' },
      { label: 'Gas', value: 'gas' },
      { label: 'Luce/Gas', value: 'luce/gas' },
    ];
    this.states = [
      { label: 'Non emessa', value: 'non_emessa' },
      { label: 'Emessa', value: 'emessa' },
      { label: 'Pagata', value: 'pagata' },
      { label: 'Nota di credito', value: 'ncr' }
    ];
  }

  generateInvoiceNumber(date: Date, type: string = 'luce'): string {
    const today = this.getFormattedDate(date);
    const t = this.getType(type);
    return `FAT${t}${today}000000`;
  }

  getType(type: string): string {
    let toRet = 'A';
    if (type === 'luce') {
      toRet = 'L';
    } else if (type === 'gas') {
      toRet = 'G';
    }
    return toRet;
  }

  getFormattedDate(date: Date): string {
    let toRet = '';
    toRet += date.getDate();
    const month = date.getMonth() + 1;
    if (month < 10) {
      toRet += '0' + month;
    }
    toRet += date.getFullYear();
    return toRet;
  }
}
