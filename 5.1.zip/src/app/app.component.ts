import {Component, OnInit} from '@angular/core';
import {Invoice} from './model/Invoice';
import {SelectItem} from 'primeng';
import {FormBuilder, FormGroup} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Create Invoice';
  invoiceForm: FormGroup;
  types: SelectItem[];
  states: SelectItem[];
  it: any;

  constructor(private formBuilder: FormBuilder) {
    this.invoiceForm = this.formBuilder.group({
      name: [''],
      customerFrom: [''],
      customerTo: [''],
      dateFrom: [new Date()],
      dateTo: [new Date()],
      amount: [1],
      tax: [27],
      total: [28],
      type: ['luce'],
      description: [''],
      state: ['emessa']
    });

    const total = this.invoiceForm.get('total');
    this.invoiceForm.valueChanges.subscribe(val => {
      total.patchValue(val.amount + val.tax, { emitEvent: false });
    });
  }

  ngOnInit(): void {
    this.it = {
      firstDayOfWeek: 1,
      dayNames: ['Domenica', 'Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato'],
      dayNamesShort: ['DOM', 'LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB'],
      dayNamesMin: ['D', 'L', 'M', 'M', 'G', 'V', 'S'],
      monthNames: ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'],
      monthNamesShort: ['GEN', 'FEB', 'MAR', 'APR', 'MAG', 'GIU', 'LUG', 'AGO', 'SET', 'OTT', 'NOV', 'DIC'],
      today: 'Oggi',
      clear: 'Cancella',
    };
    this.types = [
      { label: 'Luce', value: 'luce' },
      { label: 'Gas', value: 'gas' },
      { label: 'Luce/Gas', value: 'luce/gas' },
    ];
    this.states = [
      { label: 'Non emessa', value: 'non_emessa' },
      { label: 'Emessa', value: 'emessa' },
      { label: 'Pagata', value: 'pagata' },
      { label: 'Nota di credito', value: 'ncr' }
    ];
  }
}
