export interface Invoice {
  number: string;
  customerFrom: string;
  customerTo: string;
  dateStart: Date;
  dateEnd: Date;
  amount: number;
  tax: number;
  total: number;
  type: string;
  description?: string;
}
