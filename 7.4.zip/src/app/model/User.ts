export interface User {
  name: string;
  city: string;
  district: string;
  zipCode: string;
  email: string;
  phoneNumber: string;
  fiscalCode?: string;
  vatNumber?: string;
}
