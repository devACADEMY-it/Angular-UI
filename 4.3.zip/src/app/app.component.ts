import {Component, OnInit} from '@angular/core';
import {Invoice} from './model/Invoice';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Create Invoice';
  invoice: Invoice;

  ngOnInit(): void {
    this.invoice = {
      name: 'FATL270720200000012',
      customerFrom: 'Gennaro De Lucia',
      customerTo: 'Atlas SRL',
      dateFrom: new Date('07/27/2020'),
      dateTo: new Date('10/27/2020'),
      amount: 100,
      tax: 27,
      total: 127,
      type: 'Luce',
      description: 'Fattura per lavoro sito web',
      state: 'Emessa',
    };
  }
}
