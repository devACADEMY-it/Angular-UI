export interface Invoice {
  name: string;
  customerFrom: string;
  customerTo: string;
  dateFrom: Date;
  dateTo: Date;
  amount: number;
  tax: number;
  total: number;
  type: string;
  description?: string;
  state: string;
}
