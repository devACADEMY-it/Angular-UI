export interface Invoice {
  number: string;
  customerFrom: string;
  customerTo: string;
  dateFrom: Date;
  dateTo: Date;
  amount: number;
  tax: number;
  total: number;
  type: string;
  description?: string;
  state: string;
}
