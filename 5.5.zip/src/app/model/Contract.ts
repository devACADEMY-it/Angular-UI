export interface Contract {
  id: number;
  customer: string;
  city: string;
  registrationDate: Date;
  endDate: Date;
  status: string;
  power: number;
}
