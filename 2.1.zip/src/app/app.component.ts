import {Component, OnInit} from '@angular/core';
import {Contract} from './model/Contract';
// @ts-ignore
import { contracts } from '../assets/contracts.json';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Hello, PrimeNg';
  contracts: Contract[];

  ngOnInit(): void {
    this.contracts = contracts;
  }
}
