import { Component, OnInit } from '@angular/core';
import {User} from '../model/User';
import {UserService} from '../user.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  users: User[];
  columns: any[];

  constructor(private userService: UserService) { }

  ngOnInit(): void {
    this.users = this.userService.getUsers();
    this.columns = [
      { field: 'contractType', header: 'Tipo Contratto' },
      { field: 'name', header: 'Nome' },
      { field: 'city', header: 'Città' },
      { field: 'district', header: 'Provincia' },
      { field: 'zipCode', header: 'CAP' },
      { field: 'email', header: 'Email' },
      { field: 'phoneNumber', header: 'Telefono' },
      { field: 'fiscalCode', header: 'Codice Fiscale' },
      { field: 'vatNumber', header: 'P. IVA' }
    ];
  }
}
