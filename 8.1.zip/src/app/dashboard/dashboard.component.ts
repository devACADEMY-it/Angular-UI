import { Component, OnInit } from '@angular/core';
import {UserService} from '../user.service';
import {User} from '../model/User';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  data: any;
  users: User[];

  constructor(private userService: UserService) { }

  ngOnInit(): void {
    this.users = this.userService.getUsers();
    const totalUsers = this.users.length;
    const luce = this.users.filter((user: User) => user.contractType === 'Luce').length;
    const gas = totalUsers - luce;
    this.data = {
      labels: ['Luce', 'Gas'],
      datasets: [
        {
          data: [luce, gas],
          backgroundColor: [
            '#FF6384',
            '#36A2EB',
            '#FFCE56'
          ],
          hoverBackgroundColor: [
            '#FF6384',
            '#36A2EB',
            '#FFCE56'
          ]
        }
      ]
    };
  }

}
