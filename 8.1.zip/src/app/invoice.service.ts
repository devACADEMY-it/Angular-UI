import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class InvoiceService {
  TAX = 27;

  constructor() { }

  generateInvoiceNumber(date: Date, type: string = 'luce'): string {
    const dateStr = this.getFormattedDate(date);
    const t = this.getType(type);
    return `FAT${t}${dateStr}000000`;
  }

  getType(type: string): string {
    let toRet = 'A';
    if (type === 'luce') {
      toRet = 'L';
    } else if (type === 'gas') {
      toRet = 'G';
    }
    return toRet;
  }

  getFormattedDate(date: Date): string {
    let toRet = '';
    const day = date.getDate();
    if (day < 10) {
      toRet += '0' + day;
    } else {
      toRet += day;
    }
    const month = date.getMonth() + 1;
    if (month < 10) {
      toRet += '0' + month;
    } else {
      toRet += month;
    }
    toRet += date.getFullYear();
    return toRet;
  }
}
