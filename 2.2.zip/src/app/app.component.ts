import {Component, OnInit} from '@angular/core';
import {Contract} from './model/Contract';
// @ts-ignore
import { contracts } from '../assets/contracts.json';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Hello, PrimeNg';
  contracts: Contract[];
  columns: any[];

  ngOnInit(): void {
    this.contracts = contracts;
    this.columns = [
      { field: 'customer', label: 'Cliente' },
      { field: 'city', label: 'Città' },
      { field: 'registrationDate', label: 'Data inizio' },
      { field: 'endDate', label: 'Data fine' },
      { field: 'status', label: 'Stato' },
      { field: 'power', label: 'Potenza' }
    ];
  }
}
