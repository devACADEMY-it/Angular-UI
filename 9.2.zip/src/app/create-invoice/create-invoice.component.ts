import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {InvoiceService} from '../invoice.service';
import {SelectItem} from 'primeng';
import {ActivatedRoute} from '@angular/router';
import {UserService} from '../user.service';
import {Invoice} from '../model/Invoice';

@Component({
  selector: 'app-create-invoice',
  templateUrl: './create-invoice.component.html',
  styleUrls: ['./create-invoice.component.css']
})
export class CreateInvoiceComponent implements OnInit {
  userId: string;
  invoiceForm: FormGroup;
  types: SelectItem[];
  it: any;
  minDate: Date;
  maxDate: Date;

  constructor(
    private activatedRoute: ActivatedRoute,
    private userService: UserService,
    private fb: FormBuilder,
    private invoiceService: InvoiceService
  ) {
    this.activatedRoute.paramMap.subscribe(params => {
      this.userId = params.get('userId');
    });
    const user = this.userService.getUser(parseInt(this.userId, 10));
    const num = this.invoiceService.generateInvoiceNumber(new Date());
    this.invoiceForm = this.fb.group({
      number: [num],
      customerFrom: new FormControl({ value: 'Apollo SRL', disabled: true }),
      customerTo: new FormControl({ value: user.name, disabled: true }),
      dateFrom: [new Date()],
      dateTo: [new Date()],
      amount: [100],
      tax: new FormControl({ value: 27, disabled: true }),
      total: new FormControl({ value: 127, disabled: true }),
      type: ['Luce'],
      description: [''],
    });

    const total = this.invoiceForm.get('total');
    const tax = this.invoiceForm.get('tax');
    const invoiceNumber = this.invoiceForm.get('number');
    this.invoiceForm.valueChanges.subscribe(val => {
      const taxValue = (val.amount / 100) * this.invoiceService.TAX;
      tax.patchValue(taxValue, { emitEvent: false });
      total.patchValue(val.amount + taxValue, { emitEvent: false });
      invoiceNumber.patchValue(this.invoiceService.generateInvoiceNumber(new Date(val.dateFrom), val.type), { emitEvent: false });
    });
  }

  ngOnInit(): void {
    this.minDate = new Date();
    this.maxDate = new Date();
    this.maxDate.setMonth((this.minDate.getMonth() + 3) % 11);
    this.it = {
      firstDayOfWeek: 1,
      dayNames: ['Domenica', 'Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato'],
      dayNamesShort: ['DOM', 'LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB'],
      dayNamesMin: ['D', 'L', 'M', 'M', 'G', 'V', 'S'],
      monthNames: ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'],
      monthNamesShort: ['GEN', 'FEB', 'MAR', 'APR', 'MAG', 'GIU', 'LUG', 'AGO', 'SET', 'OTT', 'NOV', 'DIC'],
      today: 'Oggi',
      clear: 'Cancella',
    };
    this.types = [
      { label: 'Luce', value: 'luce' },
      { label: 'Gas', value: 'gas' },
    ];
  }

  onSubmit(invoice: Invoice) {
    this.invoiceService.createInvoice(invoice);
  }
}
