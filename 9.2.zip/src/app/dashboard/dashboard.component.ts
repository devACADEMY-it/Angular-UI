import { Component, OnInit } from '@angular/core';
import {UserService} from '../user.service';
import {User} from '../model/User';
import {InvoiceService} from '../invoice.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  dataUser: any;
  dataInvoice: any;
  users: User[];

  constructor(private userService: UserService, private invoiceService: InvoiceService) { }

  ngOnInit(): void {
    this.users = this.userService.getUsers();
    const totalUsers = this.users.length;
    const luce = this.users.filter((user: User) => user.contractType === 'Luce').length;
    const gas = totalUsers - luce;
    this.dataUser = {
      labels: ['Luce', 'Gas'],
      datasets: [
        {
          data: [luce, gas],
          backgroundColor: [
            '#FF6384',
            '#36A2EB',
            '#FFCE56'
          ],
          hoverBackgroundColor: [
            '#FF6384',
            '#36A2EB',
            '#FFCE56'
          ]
        }
      ]
    };
    this.dataInvoice = {
      labels: ['Maggio', 'Giugno', 'Luglio'],
      datasets: [
        {
          label: 'Fatture Luce',
          backgroundColor: '#42A5F5',
          borderColor: '#1E88E5',
          data: this.invoiceService.getInvoices().filter(invoice => invoice.type === 'Luce').map(invoice => invoice.total)
        },
        {
          label: 'Fatture Gas',
          backgroundColor: '#9CCC65',
          borderColor: '#7CB342',
          data: this.invoiceService.getInvoices().filter(invoice => invoice.type === 'Gas').map(invoice => invoice.total)
        }
      ]
    };
  }

}
