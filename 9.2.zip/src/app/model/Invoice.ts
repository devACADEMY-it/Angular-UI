export interface Invoice {
  id: number;
  number: string;
  customerFrom: string;
  customerTo: string;
  dateStart: string;
  dateEnd: string;
  amount: number;
  tax: number;
  total: number;
  type: string;
  description?: string;
}
