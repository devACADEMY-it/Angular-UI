import { Injectable } from '@angular/core';
// @ts-ignore
import { users } from '../assets/users.json';
import {User} from './model/User';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  users: User[];

  constructor() {
    this.users = users;
  }

  getUsers() {
    return this.users;
  }

  getUser(id: number) {
    return this.users.find(user => user.id === id);
  }
}
