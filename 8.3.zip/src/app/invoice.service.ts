import { Injectable } from '@angular/core';
// @ts-ignore
import { invoices } from '../assets/invoices.json';
import {Invoice} from './model/Invoice';

@Injectable({
  providedIn: 'root'
})
export class InvoiceService {
  TAX = 27;
  invoices: Invoice[];

  constructor() {
    this.invoices = invoices;
  }

  getInvoices() {
    return this.invoices.map(invoice => {
      invoice.dateStart = new Date(parseInt(invoice.dateStart, 10)).toLocaleDateString();
      invoice.dateEnd = new Date(parseInt(invoice.dateEnd, 10)).toLocaleDateString();
      return invoice;
    });
  }

  createInvoice(invoice: Invoice) {
    // API
  }

  generateInvoiceNumber(date: Date, type: string = 'luce'): string {
    const dateStr = this.getFormattedDate(date);
    const t = this.getType(type);
    return `FAT${t}${dateStr}000000`;
  }

  getType(type: string): string {
    let toRet = 'A';
    if (type === 'luce') {
      toRet = 'L';
    } else if (type === 'gas') {
      toRet = 'G';
    }
    return toRet;
  }

  getFormattedDate(date: Date): string {
    let toRet = '';
    const day = date.getDate();
    if (day < 10) {
      toRet += '0' + day;
    } else {
      toRet += day;
    }
    const month = date.getMonth() + 1;
    if (month < 10) {
      toRet += '0' + month;
    } else {
      toRet += month;
    }
    toRet += date.getFullYear();
    return toRet;
  }
}
