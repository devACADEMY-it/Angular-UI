import {Component, OnInit} from '@angular/core';
import {TreeNode} from 'primeng';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Hello, PrimeNg';
  data: TreeNode[];

  ngOnInit(): void {
    this.data = [
      {
        label: 'Sud Africa',
        expanded: true,
        children: [
          {
            label: 'Sud Africa',
            expanded: true,
            children: [
              {
                label: 'Sud Africa',
                expanded: true,
                children: [
                  {
                    label: 'Giappone'
                  },
                  {
                    label: 'Sud Africa'
                  }
                ]
              },
              {
                label: 'Galles',
                expanded: true,
                children: [
                  {
                    label: 'Galles'
                  },
                  {
                    label: 'Francia'
                  }
                ]
              }
            ]
          },
          {
            label: 'Inghilterra',
            expanded: true,
            children: [
              {
                label: 'Inghilterra',
                expanded: true,
                children: [
                  {
                    label: 'Inghilterra'
                  },
                  {
                    label: 'Australia'
                  }
                ]
              },
              {
                label: 'Nuova Zelanda',
                expanded: true,
                children: [
                  {
                    label: 'Nuova Zelanda'
                  },
                  {
                    label: 'Irlanda'
                  }
                ]
              }
            ]
          }
        ]
      }
    ];
  }
}
