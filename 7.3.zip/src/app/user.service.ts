import { Injectable } from '@angular/core';
// @ts-ignore
import { users } from '../assets/users.json';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor() { }

  getUsers() {
    return users;
  }
}
