export interface User {
  name: string;
  city: string;
  district: string;
  country: string;
  phoneNumber: string;
  vatNumber?: string;
}
