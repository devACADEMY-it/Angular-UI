import {Component, OnInit} from '@angular/core';
import {Invoice} from './model/Invoice';
import {SelectItem} from 'primeng';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Create Invoice';
  invoice: Invoice;
  types: SelectItem[];
  states: SelectItem[];

  ngOnInit(): void {
    this.invoice = {
      name: 'FATL270720200000012',
      customerFrom: 'Gennaro De Lucia',
      customerTo: 'Atlas SRL',
      dateFrom: new Date('07/27/2020'),
      dateTo: new Date('10/27/2020'),
      amount: 100,
      tax: 27,
      total: 127,
      type: 'Luce',
      description: 'Fattura per lavoro sito web',
      state: 'Emessa',
    };
    this.types = [
      { label: 'Luce', value: 'luce' },
      { label: 'Gas', value: 'gas' },
      { label: 'Luce/Gas', value: 'luce/gas' },
    ];
    this.states = [
      { label: 'Non emessa', value: 'non_emessa' },
      { label: 'Emessa', value: 'emessa' },
      { label: 'Pagata', value: 'pagata' },
      { label: 'Nota di credito', value: 'ncr' }
    ];
  }
}
