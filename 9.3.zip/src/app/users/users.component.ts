import { Component, OnInit } from '@angular/core';
import {User} from '../model/User';
import {UserService} from '../user.service';
import {MenuItem} from 'primeng';
import {Router} from '@angular/router';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  users: User[];
  columns: any[];
  items: MenuItem[];
  selectedRow: User;

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit(): void {
    this.users = this.userService.getUsers();
    this.columns = [
      { field: 'contractType', header: 'Tipo Contratto' },
      { field: 'name', header: 'Nome' },
      { field: 'city', header: 'Città' },
      { field: 'district', header: 'Provincia' },
      { field: 'zipCode', header: 'CAP' },
      { field: 'email', header: 'Email' },
      { field: 'phoneNumber', header: 'Telefono' },
      { field: 'fiscalCode', header: 'Codice Fiscale' },
      { field: 'vatNumber', header: 'P. IVA' }
    ];
    this.items = [
      { label: 'Crea Fattura', icon: 'pi pi-file', command: (event) => this.gotoCreateInvoice(this.selectedRow) },
    ];
  }

  gotoCreateInvoice(selectedRow: User) {
    this.router.navigate([`/createInvoice/${selectedRow.id}`]);
  }
}
