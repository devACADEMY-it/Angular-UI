import {Component, OnInit} from '@angular/core';
import {MenuItem} from 'primeng/api';
import {RouterOutlet} from '@angular/router';
import {slideInAnimation} from './route-animation';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [slideInAnimation]
})
export class AppComponent implements OnInit {
  title = 'Apollo SRL - Gestionale';
  items: MenuItem[];

  constructor() {}

  ngOnInit(): void {
    this.items = [
      {
        label: 'Dashboard',
        icon: 'pi pi-chart-bar',
        routerLink: ['/dashboard']
      },
      {
        label: 'Invoices',
        icon: 'pi pi-list',
        routerLink: ['/invoices']
      },
      {
        label: 'Users',
        icon: 'pi pi-users',
        routerLink: ['/users']
      }
    ];
  }

  prepareRoute(outlet: RouterOutlet) {
    return outlet && outlet.activatedRouteData && outlet.activatedRouteData.animation;
  }
}
